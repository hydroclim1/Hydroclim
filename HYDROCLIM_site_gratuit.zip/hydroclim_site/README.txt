HYDROCLIM – site web prêt à publier

Contenu :
- index.html : site responsive en français
- assets/hydroclim-cover.png : couverture fournie
- assets/hydroclim-logo.png : logo fourni

Les deux formulaires sont séparés (plomberie et climatisation) et préparent un message WhatsApp vers +216 52 180 356.
Le rendez-vous n'est pas confirmé automatiquement : le client doit envoyer le message et vous confirmer ensuite.

Publication gratuite :
1. Créez un compte GitHub et un nouveau dépôt public nommé hydroclim.
2. Importez index.html et le dossier assets.
3. Dans Settings > Pages, choisissez Deploy from a branch, puis main et /(root).
4. GitHub Pages publiera le site avec une adresse gratuite du type https://VOTRE-NOM.github.io/hydroclim/
5. Ajoutez ensuite cette adresse à Google Search Console et demandez l'indexation.

Avant publication, vérifiez que les zones d'intervention et tous les services affichés correspondent exactement à ce que vous proposez.
